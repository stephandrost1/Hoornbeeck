<?php include 'header.inc.php' ?>

<head>
    <link rel="stylesheet" href="style.css">
</head>

<body>

    <!--NAVBAR-->
    <?php include 'navbar.inc.php' ?>

</body>

</html>