<?php

session_start()

?>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Cursussen</title>
    <link rel="stylesheet" href="style.css">
</head>