<?php include 'header.inc.php' ?>

<head>
    <link rel="stylesheet" href="style.css">
</head>

<body>

    <!--NAVBAR-->
    <?php include 'navbar.inc.php' ?>

    <form action="" method="post" class="login-form">
            <div class="container">
                <label for="uname"><b>Gebruikersnaam</b></label><br>
                <input type="text" placeholder="Gebruikersnaam" name="uname"><br>

                <label for="psw"><b>Wachtwoord</b></label><br>
                <input type="password" placeholder="Wachtwoord" name="psw"> <br>

                <button id="button" type="submit" class="submit-btn borderRadius">Login</button><br>
                <p>Heb je nog geen account? <a href="Registreren.php"><u>Registreer</u></a></p>
                <?php

                if ($_POST) {

                    $con = mysqli_connect('localhost', 'root', '', 'cursussen');

                    $username = $_POST['uname'];
                    $password = $_POST['psw'];
                    $error = "";

                    if (empty($username) || empty($password)) {
                        $error = "Vul alle velden in!";
                    } else {
                        $sql = "SELECT * FROM users WHERE username = '$username' and password = '$password'";
                        $results = mysqli_query($con, $sql);
                        $array = mysqli_fetch_array($results, MYSQLI_ASSOC);
                        $amount = mysqli_num_rows($results);

                        if ($amount >= 1) {
                            $_SESSION['ingelogd'] = $_POST['uname'];
                            header('location: index.php');
                        } else {
                            $error = "Je gebruikersnaam of wachtwoord is incorrect!";
                        }
                    }

                    if ($error) {

                        echo '<p class="error">' . $error . '</p>';
                    }
                }
                ?>
            </div>
        </form>
</body>

</html>